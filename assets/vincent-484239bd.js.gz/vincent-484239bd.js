const s="/assets/bw-map-e450793a.jpeg",a="/assets/world-map-a167947e.png",e="/assets/vincent-e26b0972.webp";export{s as b,e as v,a as w};
