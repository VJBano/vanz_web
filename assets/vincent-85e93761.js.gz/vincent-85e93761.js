const a="/vanz_web/assets/bw-map-e450793a.jpeg",s="/vanz_web/assets/world-map-a167947e.png",e="/vanz_web/assets/vincent-e26b0972.webp";export{a as b,e as v,s as w};
